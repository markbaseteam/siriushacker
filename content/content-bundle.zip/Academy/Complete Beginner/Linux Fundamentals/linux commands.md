[[whoami]] - Find out what user we're currently logged in as!
[[echo]] - Output any text that we provide