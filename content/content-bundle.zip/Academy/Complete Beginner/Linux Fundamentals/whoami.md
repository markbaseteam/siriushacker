### Using whoami

```shell-session
whoami
```

![Pasted image 20230318013731.png](app://local/G:/My%20Drive/Sirius%20Hacker/THM/Academy/Complete%20Beginner/Linux%20Fundamentals/Pasted%20image%2020230318013731.png?1679121451783)