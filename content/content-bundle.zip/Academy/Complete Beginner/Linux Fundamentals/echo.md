### Using echo

```shell-session
echo
```

![Pasted image 20230318013719.png](app://local/G:/My%20Drive/Sirius%20Hacker/THM/Academy/Complete%20Beginner/Linux%20Fundamentals/Pasted%20image%2020230318013719.png?1679121439942)